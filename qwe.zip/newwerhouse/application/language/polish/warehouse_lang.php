<?php

// header

$lang['header_title'] = 'Склад от Encrypted.pl';
$lang['header_desc'] = 'Склад от Encrypted.pl';
$lang['header_keywords'] = 'Склад от Encrypted.pl';

// users
$lang['user_1'] = 'Сотрудник';
$lang['user_2'] = 'Администратор';

// footer
$lang['footer_text'] = "Склад &copy; Encrypted.pl";

// меню
$lang['menu_menu'] = "Меню";
$lang['menu_production'] = "Производство";
$lang['menu_proreport'] = "Отчет о производстве";
$lang['menu_inproduction'] = "В производстве";
$lang['menu_add_packing'] = "В пути";
$lang['menu_packing_transport'] = "Добавить список упаковки";
$lang['menu_group_packing_transport'] = "Групповое добавление списка упаковки";
$lang['menu_grouppacking_warehouse'] = "Автоматическое добавление списка упаковки";
$lang['menu_warehouse'] = "Склад";
$lang['menu_warehouse_in'] = "Прием товара - список упаковки";
$lang['menu_warehouse_groupin'] = "Групповой прием товара";
$lang['menu_warehouse_back'] = "Возврат";
$lang['menu_warehouse_correct'] = "Коррекция";
$lang['menu_warehouse_out'] = "Выдача товара";
$lang['menu_lib'] = "Библиотека";
$lang['menu_lib_products'] = "Продукты";
$lang['menu_lib_packing'] = "Списки упаковки";
$lang['menu_lib_orders'] = "Заказы";
$lang['menu_users'] = "Пользователи";
$lang['menu_manage'] = "Управление";
$lang['menu_system'] = "Система";
$lang['menu_system_log'] = "Системный журнал";
$lang['menu_system_notes'] = "Заметки";
$lang['menu_system_zero'] = "Обнуление системы";
$lang['menu_system_search'] = "Поиск";
$lang['menu_login'] = "Вход";
$lang['menu_login_user'] = "Пользователь: ";
$lang['menu_login_logout'] = "Выйти";
$lang['menu_login_login'] = "Логин:";
$lang['menu_login_passwd'] = "Пароль:";
$lang['menu_login_signin'] = "Войти";
$lang['menu_backup'] = "Резервное копирование";
$lang['menu_crm'] = "CRM";
$lang['menu_clients'] = "Клиенты";
$lang['menu_documents'] = "Документы";
$lang['menu_reports'] = "Отчеты";

// h1

$lang['h1_add_product_production'] = "Добавление продукта в производство";
$lang['h1_add_packing_onway'] = "Добавление списка упаковки в пути";
$lang['h1_add_packing_grouponway'] = "Блокировка + добавление списка упаковки в пути";
$lang['h1_add_packing_warehouse'] = "Добавление списка упаковки на склад";
$lang['h1_add_grouppacking_warehouse'] = "Групповое добавление списка упаковки на склад";
$lang['h1_add_autopacking_warehouse'] = "Автоматическое добавление списка упаковки на склад";
$lang['h1_add_return'] = "Добавление продукта - возврат";
$lang['h1_add_correction'] = "Коррекция состояния на складе";
$lang['h1_add_sent'] = "Выдача товара";
$lang['h1_add_product'] = "Добавление нового продукта";
$lang['h1_lib_manage'] = "Управление продуктами";
$lang['h1_add_packing'] = "Добавление списка упаковки";
$lang['h1_add_order'] = "Добавление заказа";
$lang['h1_add_client'] = "Добавление клиента";
$lang['h1_users_manage'] = "Управление пользователями";
$lang['h1_users_manage_add'] = "Добавление или редактирование пользователя";
$lang['h1_notes_manage'] = "Управление заметками";
$lang['h1_notes_manage_add'] = "Добавление или редактирование заметок";
$lang['h1_report'] = "Журнал системных действий";
$lang['h1_proreport'] = "Журнал производства";
$lang['h1_status'] = "Текущее состояние склада";
$lang['h1_search'] = "Поиск";
$lang['h1_noaccess'] = "Нет доступа";
$lang['h1_add_documents_to_client'] = "Добавление документов клиенту";
$lang['h1_pick_client'] = "Документы - выбор клиента";
$lang['h1_add_products_to_document'] = 'Добавление продуктов в документ';
$lang['h1_preparing_report'] = 'Выберите данные для генерации отчета';
$lang['h1_report_crm'] = 'Отчет CRM';

// h2

$lang['h2_zero_all'] = "Обнулить числовые значения";
$lang['h2_zero_all_info'] = "Числовые значения обнулены!!!";
$lang['h2_zero_pro'] = "Обнулить продукты";
$lang['h2_zero_pro_info'] = "Продукты обнулены!!!";
$lang['h2_zero_desc'] = "Обнулить значения для описания в производстве";
$lang['h2_zero_desc_info'] = "Значения для описания в производстве обнулены!!!";
$lang['h2_zero_desc_error_info'] = "Значения для описания в производстве НЕ обнулены!!!";

// глобальные строки

$lang['product'] = "Продукт";
$lang['client'] = "Клиент";
$lang['order'] = "Заказ";
$lang['packing'] = "Список упаковки";
$lang['amount'] = "Количество";
$lang['id'] = "Id";
$lang['desc'] = "Описание";
$lang['name'] = "Название";
$lang['actions'] = "Действия";
$lang['login'] = "Логин";
$lang['level'] = "Уровень";
$lang['passwd'] = "Пароль";
$lang['data'] = "Дата";
$lang['data_start'] = "Начальная дата (включительно)";
$lang['data_end'] = "Конечная дата (включительно)";
$lang['title'] = "Заголовок";
$lang['text'] = "Текст";
$lang['new'] = "Добавить новую запись";
$lang['edit'] = "Редактировать";
$lang['del'] = "Удалить";
$lang['back'] = "Назад";
$lang['home'] = "Главная";
$lang['return'] = "Возврат";
$lang['correction'] = "Коррекция";
$lang['sent'] = "Выдача";
$lang['print'] = "Печать";
$lang['no'] = "Нет";
$lang['yes'] = "Да";
$lang['back_packings'] = "Назад к спискам упаковки";
$lang['code'] = "Код";
$lang['ean'] = "EAN";
$lang['group'] = "Группа";
$lang['system'] = "Система";
$lang['total'] = "Всего";
$lang['log_type'] = "Тип записи";
$lang['log_user'] = "Пользователь";
$lang['log_desc'] = "Описание";
$lang['all'] = "Все";
$lang['year'] = "Год";
$lang['month'] = "Месяц";
$lang['day'] = "День";
$lang['hour'] = "Час";
$lang['minute'] = "Минута";
$lang['second'] = "Секунда";
$lang['search'] = "Поиск";
$lang['submit'] = "Выполнить";
$lang['search_text'] = "Введите текст для поиска";
$lang['search_button'] = "Искать";
$lang['search_result'] = "Результаты поиска";
$lang['search_not_found'] = "Ничего не найдено";
$lang['search_back'] = "Вернуться к результатам поиска";
$lang['search_type'] = "Тип поиска";
$lang['search_all'] = "Все";
$lang['search_products'] = "Продукты";
$lang['search_clients'] = "Клиенты";
$lang['search_orders'] = "Заказы";
$lang['search_packings'] = "Списки упаковки";
$lang['search_documents'] = "Документы";
$lang['search_notes'] = "Заметки";
$lang['search_users'] = "Пользователи";
$lang['search_logs'] = "Журналы";
$lang['search_date_range'] = "Диапазон дат";
$lang['search_custom_range'] = "Выбрать диапазон";
$lang['search_select_range'] = "Выберите диапазон";
$lang['search_today'] = "Сегодня";
$lang['search_yesterday'] = "Вчера";
$lang['search_last_7'] = "Последние 7 дней";
$lang['search_last_30'] = "Последние 30 дней";
$lang['search_this_month'] = "Текущий месяц";
$lang['search_last_month'] = "Прошлый месяц";
$lang['search_this_year'] = "Текущий год";
$lang['search_last_year'] = "Прошлый год";
$lang['search_apply'] = "Применить";
$lang['search_reset'] = "Сбросить";
$lang['search_export'] = "Экспорт";
$lang['search_export_csv'] = "Экспорт в CSV";
$lang['search_export_excel'] = "Экспорт в Excel";

// сообщения

$lang['msg_loading'] = "Загрузка...";
$lang['msg_saving'] = "Сохранение...";
$lang['msg_deleting'] = "Удаление...";
$lang['msg_sending'] = "Отправка...";
$lang['msg_confirm_delete'] = "Вы уверены, что хотите удалить?";
$lang['msg_confirm_action'] = "Вы уверены, что хотите выполнить это действие?";
$lang['msg_success'] = "Успешно!";
$lang['msg_error'] = "Ошибка!";
$lang['msg_invalid_data'] = "Неверные данные!";
$lang['msg_server_error'] = "Ошибка сервера!";
$lang['msg_no_access'] = "Нет доступа!";
$lang['msg_not_found'] = "Не найдено!";
$lang['msg_search_empty'] = "Введите текст для поиска!";
$lang['msg_search_no_results'] = "Нет результатов поиска!";
$lang['msg_search_export_success'] = "Экспорт успешно выполнен!";
$lang['msg_search_export_error'] = "Ошибка при выполнении экспорта!";

