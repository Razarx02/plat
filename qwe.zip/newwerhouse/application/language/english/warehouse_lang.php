<?php

// header

$lang['header_title'] = 'Менеджмент склада';
$lang['header_desc'] = 'Менеджмент склада';
$lang['header_keywords'] = 'Менеджмент склада';

// users
$lang['user_1'] = 'Работник';
$lang['user_2'] = 'Администратор';

// footer
$lang['footer_text'] = "Warehouse &copy;";

// menu
$lang['menu_menu'] = "Меню";
$lang['menu_production'] = "Производство";
$lang['menu_proreport'] = "Производственный отчет";
$lang['menu_inproduction'] = "Добавить к производству";
$lang['menu_add_packing'] = "В пути";
$lang['menu_packing_transport'] = "Добавление упаковочного листа";
$lang['menu_group_packing_transport'] = "Группа, добавляющая упаковочный лист";
$lang['menu_grouppacking_warehouse'] = "Автоматическое добавление упаковочного листа";
$lang['menu_warehouse'] = "Склад";
$lang['menu_warehouse_in'] = "Доход от упаковочного листа";
$lang['menu_warehouse_groupin'] = "Упаковочный лист групповой доход";
$lang['menu_warehouse_back'] = "Назад";
$lang['menu_warehouse_correct'] = "Правка";
$lang['menu_warehouse_out'] = "Исход";
$lang['menu_warehouse_report'] = "Отчет о складе";
$lang['menu_lib'] = "Библиотека";
$lang['menu_lib_products'] = "Продукты";
$lang['menu_lib_packing'] = "Упаковочные листы";
$lang['menu_lib_orders'] = "Заказы";
$lang['menu_users'] = "Пользователи";
$lang['menu_manage'] = "Управлять";
$lang['menu_system'] = "Система";
$lang['menu_system_log'] = "Системный журнал";
$lang['menu_system_notes'] = "Записи";
$lang['menu_system_zero'] = "Клиринговая система";
$lang['menu_system_search'] = "Системный поиск";
$lang['menu_login'] = "Вход в систему";
$lang['menu_login_user'] = "Пользователь: ";
$lang['menu_login_logout'] = "Выход из системы";
$lang['menu_login_login'] = "Авторизоваться:";
$lang['menu_login_passwd'] = "Пароль:";
$lang['menu_login_signin'] = "Регистрироваться";
$lang['menu_backup'] = "Резервная копия";
$lang['menu_crm'] = "CRM";
$lang['menu_clients'] = "Клиентки";
$lang['menu_documents'] = "Документы";
$lang['menu_reports'] = "Отчет";

// h1

$lang['h1_add_product_production'] = "Добавление продуктов в производство";
$lang['h1_add_packing_onway'] = "Добавление упаковочного листа в пути";
$lang['h1_add_packing_grouponway'] = "Группа, добавляющая упаковочный лист в пути";
$lang['h1_add_packing_warehouse'] = "Добавление упаковочного листа на склад";
$lang['h1_add_grouppacking_warehouse'] = "Группа, добавляющая упаковочный лист на склад";
$lang['h1_add_autopacking_warehouse'] = "Автоматическое добавление упаковочного листа на склад ";
$lang['h1_add_return'] = "Добавление товара - возврат";
$lang['h1_add_correction'] = "Correction";
$lang['h1_add_sent'] = "Конечный результат продукта";
$lang['h1_add_product'] = "Добавление нового продукта";
$lang['h1_lib_manage'] = "Управление продуктами";
$lang['h1_add_packing'] = "Добавление упаковочного листа";
$lang['h1_add_order'] = "Добавление заказа";
$lang['h1_users_manage'] = "Управление пользователями";
$lang['h1_users_manage_add'] = "Добавление или редактирование пользователя";
$lang['h1_notes_manage'] = "Управление заметками";
$lang['h1_notes_manage_add'] = "Добавление или редактирование заметок";
$lang['h1_report'] = "Журнал системных действий";
$lang['h1_proreport'] = "Производственный журнал";
$lang['h1_status'] = "Текущее состояние склада";
$lang['h1_search'] = "Поиск";
$lang['h1_noaccess'] = "Нет доступа";
$lang['h1_add_documents_to_client'] = "Добавление документов в клиент";
$lang['h1_pick_client'] = "Выберите клиента";
$lang['h1_add_products_to_document'] = 'Добавление продуктов в документ';
$lang['h1_preparing_report'] = 'Подготовка отчета';
$lang['h1_report_crm'] = 'Отчет CRM';

// h2

$lang['h2_zero_all'] = "Удалить числовые значения";
$lang['h2_zero_all_info'] = "Числовые значения удалены!!!";
$lang['h2_zero_pro'] = "Удалять продукты";
$lang['h2_zero_pro_info'] = "Товары удалены!!!";
$lang['h2_zero_desc'] = "Удалить для данного описания в процессе производства";
$lang['h2_zero_desc_info'] = "Числовое значение для описания удалено в процессе производства!!!";
$lang['h2_zero_desc_error_info'] = "Числовое значение для описания, не удаленное в процессе производства!!!";

// global strings

$lang['product'] = "Продукт";
$lang['client'] = "Клиент";
$lang['order'] = "Заказ";
$lang['packing'] = "Товарная накладная";
$lang['amount'] = "Сумма";
$lang['id'] = "Id";
$lang['desc'] = "Описание";
$lang['name'] = "Имя";
$lang['actions'] = "Действия";
$lang['login'] = "Авторизоваться";
$lang['level'] = "Уровень";
$lang['passwd'] = "Пароль";
$lang['data'] = "Дата";
$lang['data_start'] = "Дата начала";
$lang['data_end'] = "Дата окончания";
$lang['title'] = "Заглавие";
$lang['text'] = "Содержание";
$lang['new'] = "Добавить новый";
$lang['edit'] = "Редактировать";
$lang['confirm_delete'] = "'Пожалуйста, подтвердите удаление. Эта операция не может быть отменена.'";
$lang['del'] = "Удалить";
$lang['generate'] = "Генерировать";
$lang['submit'] = "Отправить запрос";
$lang['lib'] = "Библиотека";
$lang['wh'] = "Склад";
$lang['onway'] = "В пути";
$lang['production'] = "В производстве";
$lang['total'] = "Вcего";
$lang['given'] = "Всего дано";
$lang['all'] = "Все";
$lang['all_desc'] = "Все описания";
$lang['confirm'] = "Подтверждать";
$lang['print'] = "Печать";
$lang['print_csv'] = "Печать CSV-файла";
$lang['backup_info'] = "Вы собираетесь сделать полную резервную копию MySQL этой базы данных хранилища, вы можете восстановить эту резервную копию в любое время, выполнив загруженный SQL-скрипт в вашей базе данных";
$lang['submit'] = 'Представить';
$lang['back_to_add'] = 'Перейти к списку';
$lang['documents'] = 'Документы';
$lang['file'] = 'Файл';
$lang['start_date'] = 'Дата начала';
$lang['end_date'] = 'Дата окончания';
$lang['view'] = 'Смотреть';
$lang['products_list'] = 'Список продуктов';
$lang['lists_type'] = 'Тип';
$lang['req'] = 'Запрошенный';
$lang['bought'] = 'Купил';
$lang['subject'] = 'Предмет';
$lang['date'] = 'Дата';
$lang['percent'] = 'Процент';

// actions

$lang['action_1'] = 'изменение производства';
$lang['action_2'] = 'склад возвращают обратно';
$lang['action_3'] = 'коррекция склада';
$lang['action_4'] = 'склад выдает';
$lang['action_5'] = 'изменение в упаковочном листе';
$lang['action_6'] = 'добавить упаковку на склад';

// long txt

$lang['long_noaccess'] = 'У вас нет разрешения на отображение этой страницы!';
$lang['long_welcome_header'] = 'Добро пожаловать';
$lang['long_welcome_text'] = 'Добро пожаловать';
