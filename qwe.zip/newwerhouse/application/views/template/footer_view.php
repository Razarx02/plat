<!-- footer area -->    
<!-- #end footer area --> 


<!-- jQuery -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url(); ?>js/libs/jquery-1.9.0.min.js">\x3C/script>')</script>

<script defer src="<?php echo base_url(); ?>js/flexslider/jquery.flexslider-min.js"></script>

<!-- fire ups - read this file!  -->   
<script src="<?php echo base_url(); ?>js/main.js"></script>

<!-- tables to CSV -->
<?php if ($this->router->fetch_class() != 'main') { ?>
<script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.1.min.js" ></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js/table2CSV.js" ></script>
<?php } ?>
</body>
</html>