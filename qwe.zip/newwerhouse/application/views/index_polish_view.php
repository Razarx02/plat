<?php $this->load->view('template/header_view.php'); ?>

    <!-- hero area (the grey one with a slider -->
    <section id="hero" class="clearfix">
        <!-- responsive FlexSlider image slideshow -->
        <div class="wrapper">
            <div class="row">
                <div class="grid_5">
                    <h1>Проект "Учет и управление складом" </h1>
                    <p>Разработка  логистической системы учета на складе</p>
                </div>
                <div class="grid_7 rightfloat">
                    <div class="flexslider">
                        <ul class="slides">
                            
                            <li>
                                <img src="<?php echo base_url(); ?>images/warehouse-pic4.jpg"/>
                                <p class="flex-caption">Системный журнал, чтобы ничего не упустить.</p>
                            </li>
                            
                            <li>
                                <img src="<?php echo base_url(); ?>images/warehouse-pic1.jpg"/>
                                <p class="flex-caption">Резервное копирование в одно касание.</p>
                            </li>
                            <li>
                                <img src="<?php echo base_url(); ?>images/warehouse-pic3.jp"/>
                                <p class="flex-caption">Отзывчивый шаблон - воспроизводимый на устройствах.</p>
                            </li>
                            <li>
                                <img src="<?php echo base_url(); ?>images/warehouse-pic2.jpg"/>
                                <p class="flex-caption">Простой экспорт CSV (для воспроизведения в Microsoft Excel или
                                    Расчет).</p>
                            </li>
                        </ul>
                    </div><!-- FlexSlider -->
                </div><!-- end grid_7 -->
            </div><!-- end row -->
        </div><!-- end wrapper -->
    </section><!-- end hero area -->

<?php $this->load->view('template/footer_view.php'); ?>